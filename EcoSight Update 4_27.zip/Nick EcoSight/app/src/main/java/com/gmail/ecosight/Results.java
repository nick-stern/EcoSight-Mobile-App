package com.gmail.ecosight;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.gmail.ecosight.Maps;
import com.gmail.ecosight.R;
import com.gmail.ecosight.ResultsAdapter;

public class Results extends AppCompatActivity {

    ListView resultsListView;
    String[] latitude;
    String[] cities;
    String[] longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        /*
        Resources res = getResources();
        resultsListView = (ListView) findViewById(R.id.resultListView);
        latitude = res.getStringArray(R.array.latitude);
        longitude = res.getStringArray(R.array.longitude);
        cities = res.getStringArray(R.array.cities);
        */
        resultsListView = (ListView) findViewById(R.id.resultListView);
        cities = getIntent().getStringArrayExtra("name");
        latitude = getIntent().getStringArrayExtra("lat");
        longitude = getIntent().getStringArrayExtra("lon");

        // uses the new adapter to display the results
        ResultsAdapter resultsAdapter = new ResultsAdapter(this, latitude, longitude, cities);
        resultsListView.setAdapter(resultsAdapter);

        resultsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            /*
             * @param parent The AdapterView where the click happened.
             * @param view The view within the AdapterView that was clicked (this
             *            will be a view provided by the adapter)
             * @param position The position of the view in the adapter.
             * @param id The row id of the item that was clicked.
             */
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                int x = view.getId();
                System.out.println(x);

                Intent mapIntent = new Intent(getApplicationContext(), Maps.class);
                mapIntent.putExtra("lat",latitude);
                mapIntent.putExtra("lon",longitude);
                mapIntent.putExtra("name",cities);
                mapIntent.putExtra("activity", "Results");
                mapIntent.putExtra("position",position);
                startActivity(mapIntent);


            }
        });
    }

}
