package com.gmail.ecosight;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ResultsAdapter extends BaseAdapter {

    // this class prepares the results to be displayed on the Results activity

    LayoutInflater mInflater;
    String[] latitude;
    String[] cities;
    String[] longitude;

    public ResultsAdapter(Context c, String[] la, String[] lo, String[] city){
        latitude = la;
        longitude = lo;
        cities = city;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return cities.length;
    }

    @Override
    public Object getItem(int i) {
        return cities[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {

        // get details of format from results_listview_detail.xml
        View v = mInflater.inflate(R.layout.results_listview_detail, null);
        TextView citiesTextView = (TextView) v.findViewById(R.id.cityTextView);
        TextView latTextView = (TextView) v.findViewById(R.id.latTextView);
        TextView longTextView = (TextView) v.findViewById(R.id.longTextView);

        String city = cities[i];
        String lat = latitude[i];
        String lon = longitude[i];

        citiesTextView.setText(city);
        latTextView.setText(lat);
        longTextView.setText(lon);

        return v;
    }

}
