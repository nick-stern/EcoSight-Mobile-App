package com.gmail.ecosight;

import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;

import com.gmail.ecosight.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class Maps extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    String[] cities, latitude, longitude;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);

        // If the call to this activity was from History it does the first if, if it was from Results it does the second
        if(getIntent().getStringExtra("activity").equals("History")) {
            cities = getIntent().getStringArrayExtra("name");
            latitude = getIntent().getStringArrayExtra("lat");
            longitude = getIntent().getStringArrayExtra("lon");
            float zoomLevel = 13.0f;
            // Add a marker to location and move the camera
            for(int i = 0; i < latitude.length; i++) {
                LatLng x = new LatLng(Double.valueOf(latitude[i]), Double.valueOf(longitude[i]));
                mMap.addMarker(new MarkerOptions().position(x).title(cities[i]));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(x, zoomLevel));
            }
        } else if(getIntent().getStringExtra("activity").equals("Results")){
            cities = getIntent().getStringArrayExtra("name");
            latitude = getIntent().getStringArrayExtra("lat");
            longitude = getIntent().getStringArrayExtra("lon");
            position = getIntent().getIntExtra("position", 0);
            float zoomLevel = 13.0f;
            // Add a marker to location and move the camera
            for(int i = 0; i < latitude.length; i++) {
                LatLng x = new LatLng(Double.valueOf(latitude[i]), Double.valueOf(longitude[i]));
                mMap.addMarker(new MarkerOptions().position(x).title(cities[i]));
            }
            LatLng y = new LatLng(Double.valueOf(latitude[position]), Double.valueOf(longitude[position]));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(y, zoomLevel));
        }

    }

}
