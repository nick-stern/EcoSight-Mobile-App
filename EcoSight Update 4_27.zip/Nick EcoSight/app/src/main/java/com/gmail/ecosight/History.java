package com.gmail.ecosight;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.gmail.ecosight.Maps;
import com.gmail.ecosight.R;
import com.gmail.ecosight.Results;

public class History extends AppCompatActivity {

    String[] latitude;
    String[] longitude;
    String[] name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        Button mapBtn = (Button) findViewById(R.id.mapBtn);
        mapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mapIntent = new Intent(getApplicationContext(), Maps.class);
                latitude = getIntent().getStringArrayExtra("lat");
                longitude = getIntent().getStringArrayExtra("lon");
                name = getIntent().getStringArrayExtra("name");
                mapIntent.putExtra("lat",latitude);
                mapIntent.putExtra("lon",longitude);
                mapIntent.putExtra("name",name);
                mapIntent.putExtra("activity", "History");
                startActivity(mapIntent);
            }
        });

        // display results class
        Button resultsBtn = (Button) findViewById(R.id.resultsBtn);
        resultsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultsIntent = new Intent(getApplicationContext(), Results.class);
                latitude = getIntent().getStringArrayExtra("lat");
                longitude = getIntent().getStringArrayExtra("lon");
                name = getIntent().getStringArrayExtra("name");
                resultsIntent.putExtra("lat",latitude);
                resultsIntent.putExtra("lon",longitude);
                resultsIntent.putExtra("name",name);
                startActivity(resultsIntent);
            }
        });
    }
}
